How to run the Shopping Portal (shopping) Project

1. Download the  zip file

2. Extract the file and copy shopping folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name shopping

6. Import shopping.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/shopping (frontend)



Credential for admin panel :

Username: admin
Password: Test@123

Credential for  User panel :

Username: john@gmail.com
Password: Test@12345

 Or Register a new User.